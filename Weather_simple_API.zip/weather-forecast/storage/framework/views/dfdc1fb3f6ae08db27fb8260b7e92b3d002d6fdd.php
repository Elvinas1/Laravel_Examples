<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather App</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Weather App</h1>
        <form action="/weather" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="location">City:</label>
                <input type="text" id="location" name="location" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Get Weather</button>
        </form>
        <?php if(isset($weather)): ?>
        <h2>Weather in <?php echo e($location); ?></h2>
        <p>Temperature: <?php echo e($weather['main']['temp'] - 273.15); ?>°C</p>
        <p>Humidity: <?php echo e($weather['main']['humidity']); ?>%</p>
        <p>Wind Speed: <?php echo e($weather['wind']['speed']); ?> m/s</p>
        <p>Clouds: <?php echo e($weather['clouds']['all']); ?>%</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\jazze\OneDrive\Desktop\Laravel\Laravel - Weather_API\weather-forecast\resources\views/welcome.blade.php ENDPATH**/ ?>