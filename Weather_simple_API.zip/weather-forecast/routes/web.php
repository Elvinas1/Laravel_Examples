<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/weather', function (Request $request) {
    $location = $request->input('location');
    $api = '8229135bbaa33e2241135d0aede4c883';
    $response = Http::get("https://api.openweathermap.org/data/2.5/weather?q={$location}&appid={$api}");
    $weather = $response->json();

    return view('welcome', ['weather' => $weather, 'location' => $location]);
});
